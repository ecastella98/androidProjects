package com.example.bbdd_estercastella;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBInterface {

    // Constants.
    public static final String CLAU_ID = "_id";
    public static final String CLAU_NOM = "nom";
    public static final String CLAU_EMAIL = "email";

    public static final String TAG = "DBInterface";

    public static final String DB_NOM = "DBClients";
    public static final String DB_TAULA = "contactes";
    public static final int VERSIO = 1;

    public static final String DB_CREATE = "create table " + DB_TAULA + "(" + CLAU_ID + " integer primary key autoincrement, "
            + CLAU_NOM + " text not null, " + CLAU_EMAIL + " text not null);";

    private final Context context;
    private DbHelper ajuda;
    private SQLiteDatabase db;

    public DBInterface (Context con) {
        this.context = con;
        ajuda = new DbHelper(context);
    }
    private static class DbHelper extends SQLiteOpenHelper {
        DbHelper(Context con) {
            super(con,DB_NOM,null,VERSIO);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(DB_CREATE);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG,"Actualitzant la base de dades de la versió " + oldVersion + " a" + newVersion + ". Es destruiràn totes les dades!");
            db.execSQL(("DROP TABLE IF EXISTS " + DB_TAULA));
            onCreate(db);
        }
    }

    public DBInterface obrir() throws SQLException {
        db = ajuda.getWritableDatabase();
        return this;
    }

    public void tancar() {
        ajuda.close();
    }

    public long inserirContacte(String nom, String email) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(CLAU_NOM, nom);
        initialValues.put(CLAU_EMAIL, email);
        return db.insert(DB_TAULA,null,initialValues);
    }

    public boolean esborrarContacte (long IDfila) {
        return db.delete(DB_TAULA,CLAU_ID+"="+IDfila,null)>0;
    }

    public Cursor obtenirContacte (long IDfila) throws SQLException {
        Cursor mCursor = db.query(true,DB_TAULA,new String[]{CLAU_ID,CLAU_NOM,CLAU_EMAIL},
                CLAU_ID+"="+IDfila,null,null,null,null,null
        );
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return  mCursor;
    }

    public Cursor obtenirTotsContactes() {
        return db.query(DB_TAULA,new String[]{CLAU_ID,CLAU_NOM,CLAU_EMAIL},null,null,null,null,null);
    }

    public boolean modificarContacte(long IDfila,String nom,String email) {
        ContentValues args = new ContentValues();
        args.put(CLAU_NOM,nom);
        args.put(CLAU_EMAIL,email);
        return db.update(DB_TAULA,args,CLAU_ID+"="+IDfila,null)>0;
    }
}