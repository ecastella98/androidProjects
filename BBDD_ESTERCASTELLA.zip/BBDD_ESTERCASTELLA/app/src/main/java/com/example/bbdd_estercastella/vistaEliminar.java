package com.example.bbdd_estercastella;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class vistaEliminar extends AppCompatActivity {

    public DBInterface bd;
    EditText et_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_eliminar);
        et_id = findViewById(R.id.et_id);
    }

    public void onClick(View v) {
        //Obrim la BD
        bd = new DBInterface(this);
        bd.obrir();

        //Obtenim l’ID de la caixa de text
        long id = Long.parseLong(et_id.getText().toString());

        //Cridem la BD
        boolean result = bd.esborrarContacte(id);

        //Comprovem el resultat de l’operació
        if (result)
            Toast.makeText(this, "Element esborrat", Toast.LENGTH_SHORT).
                    show();
        else
            Toast.makeText(this, "No s’ha pogut esborrar l’element", Toast.
                    LENGTH_SHORT).show();
        //Tanquem la BD
        bd.tancar();

        //Tanquem l’activitat
        finish();
    }
}
