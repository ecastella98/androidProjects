package com.example.bbdd_estercastella;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class vistaModificar extends AppCompatActivity {

    public DBInterface bd;
    EditText et_id, et_nom, et_correu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_modificar);
        et_id = findViewById(R.id.et_id);
        et_nom = findViewById(R.id.et_nomcontacte);
        et_correu = findViewById(R.id.et_correu);
    }


    public void onClick(View v) {
        long id;

         //Obtenim la BD
         bd = new DBInterface(this);
         bd.obrir();

         //Identificador de la caixa de text
         id = Long.parseLong(et_id.getText().toString());

         //Crida a la BD
         boolean result = bd.modificarContacte(id, et_nom.getText().toString(), et_correu.getText().toString());

         //Comprovem el resultat, si s’ha pogut actualitzar la BD o no
         if (result)
             Toast.makeText(this, "Element modificat", Toast.LENGTH_SHORT).
                show();
         else
         Toast.makeText(this, "No s’ha pogut modificar l’element", Toast
                .LENGTH_SHORT).show();

         //Tanquem la BD
         bd.tancar();

         //Tanca l’activitat.
         finish();
         }
}
