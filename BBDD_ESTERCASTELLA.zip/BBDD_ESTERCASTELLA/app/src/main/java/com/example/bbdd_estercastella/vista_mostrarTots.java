package com.example.bbdd_estercastella;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class vista_mostrarTots extends AppCompatActivity {

    public DBInterface bd;
    private ListView listview;
    private ArrayList<String> names;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_mostrar_tots);

        //Obrir base de dades
        bd = new DBInterface(this);
        bd.obrir();

        //Crida la BD per obtenir tots els contactes
        Cursor c = bd.obtenirTotsContactes();

        //Movem el cursor a la primera posició
        //if (c.moveToFirst()) {
       //     do {
       //         //Mostrem contactes...
       //         MostraContacte(c);
        //        //... mentre puguem passar al següent contacte
        //    } while (c.moveToNext());
        //}



        listview = (ListView) findViewById(R.id.listView);

        String[] names = new String[c.getCount()*3];
        if (c.moveToFirst()){
            int i = 0;
            do{
                names[i]=c.getString(0);
                i++;
                names[i]=c.getString(1);
                i++;
                names[i]=c.getString(2);
                i++;

            }
            while (c.moveToNext());
        }


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names);

        listview.setAdapter(adapter);



        //Tanquem la BD
        bd.tancar();
        Toast.makeText(this, "Tots els contactes mostrats", Toast.LENGTH_SHORT).show();
        }

       // public void MostraContacte(Cursor c) {
         //Toast.makeText(this, "id: "+ c.getString(0) + "\n" + "Nom: "+ c.getString(1) + "\n Email: " + c.getString(2), Toast.LENGTH_SHORT).show();
         //}
}
