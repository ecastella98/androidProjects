package com.example.bbdd_estercastella;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btn_inserir, btn_modificar,btn_mostrarContacte,btn_mostrar2Contactes,btn_borrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_inserir = findViewById(R.id.btn_inserir);
        btn_modificar = findViewById(R.id.btn_modificar);
        btn_mostrarContacte = findViewById(R.id.btn_mostrarContacte);
        btn_mostrar2Contactes = findViewById(R.id.btn_mostrar2Contactes);
        btn_borrar = findViewById(R.id.btn_borrar);

    }

    public void onClick(View v){
        if(v == btn_inserir){
            startActivity(new Intent(this,vistaInserir.class));
        }
        else if(v == btn_modificar){
                startActivity(new Intent(this,vistaModificar.class));
        }
        else if(v == btn_mostrarContacte){
            startActivity(new Intent(this,vista_mostrarUn.class));
        }
        else if(v == btn_mostrar2Contactes){
            startActivity(new Intent(this,vista_mostrarTots.class));
        }
        else if(v == btn_borrar){
            startActivity(new Intent(this,vistaEliminar.class));
        }

    }
}
