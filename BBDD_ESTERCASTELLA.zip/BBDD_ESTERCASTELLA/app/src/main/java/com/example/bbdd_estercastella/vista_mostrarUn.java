package com.example.bbdd_estercastella;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class vista_mostrarUn extends AppCompatActivity {

    public DBInterface bd;
    EditText et_nom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_mostrar_un);
        et_nom = findViewById(R.id.et_id);
    }


    public void onClick(View v) {
        //Botó obtenir
         Cursor c;

        //Obrim la base de dades
         bd = new DBInterface(this);
         bd.obrir();

         //Aquest és l’identificador que està escrit a la caixa de text
         long id = Long.parseLong(et_nom.getText().toString());

         //Crida a la BD
         c = bd.obtenirContacte(id);

         // Comprovem si hi ha hagut algun resultat
         if (c.getCount() != 0) {
             //Mostrem el contacte
             Toast.makeText(this, "id: " + c.getString(0) + "\n" + "Nom: " + c.getString(1) + "\n Email: " + c.getString(2), Toast.LENGTH_SHORT).show();
             } else {
             Toast.makeText(this, "id inexistent!", Toast.LENGTH_SHORT).show();
             }
         //Tanquem la BD
         bd.tancar();

         //Tanca l’activitat
         finish();
         }

}
