package com.example.bbdd_estercastella;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class vistaInserir extends AppCompatActivity {

    public DBInterface bd;
    EditText et_nom, et_correu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_inserir);
        et_nom = findViewById(R.id.et_id);
        et_correu = findViewById(R.id.et_correu);
    }


    public void onClick(View v) {

           //Obrim la base de dades
           bd = new DBInterface(this);
           bd.obrir();
           //Inserim el contacte
            if(bd.inserirContacte(et_nom.getText().toString(), et_correu.getText().toString()) != -1) {
                 Toast.makeText(this, "Afegit correctament", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error a l’afegir", Toast.LENGTH_SHORT).show();
            }
            bd.tancar();
            finish();

        }



}
